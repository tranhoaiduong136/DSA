#include "VM.h"

void VM::run(string filename)
{
	cout << 1;
}