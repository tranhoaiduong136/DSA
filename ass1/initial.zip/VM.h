#ifndef VM_H
#define VM_H

#include "main.h"


class VM
{
public:
  VM(){}
  void run(string filename);
};
#endif